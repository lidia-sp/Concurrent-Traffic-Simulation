#include <random>
#include <iostream>

int main(){
std::random_device rd;
std::mt19937 eng(rd());
std::uniform_real_distribution<> distr(4000.0, 6000.0);
std::cout<<distr(eng)<< "second "<< distr(eng);
return 0;
}